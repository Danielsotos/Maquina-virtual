#include <Arduino.h>

void setup();
void loop();
#line 1 "src/sketch.ino"
void setup(){} void loop(){}
#!/bin/bash

cd "/var/www/html/temp_files/$1"
sudo ino build


<?php

session_start();

if(isset($_SESSION["user_id"])){
 header("location:home.php");
}

?>

<!DOCTYPE html>
<html>
 <head>
  <title>Mi Laboratorio Remoto</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <script src="http://code.jquery.com/jquery.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <style type="text/css">
  @import url("slkscr/stylesheet.css");
  .silkscreen {
    font-family: slkscr;
  }
  .panel > .panel-heading {
    background-image: none;
    background-color: #8D03D6;
    color: #8D03D6;
  }
  .btn-primary, .btn-primary:hover, .btn-primary:active, .btn-primary:visited {
    background-color: #8D03D6 !important;
  }
  </style>
 </head>
 <body style="background:#FF4800";>
  <br />
  <div class="container">
   <h3 align="center" style="color: #FFFFFF; font-family: slkscr;"><a href="http://www.practicasremotas.com/index.php" style="color: #FFFFFF">Mi Laboratorio Remoto ( ^ _ ^ )</a></h3>
   <br />
   <?php
   if(isset($_GET["register"])){
    if($_GET["register"] == 'success'){
     echo '<h1 class="text-success" style="color: #FFFFFF; font-family: slkscr;">¡Registro verificado exitosamente! <br>Ya puedes ocupar nuestros laboratorios.</h1>';
    }
   }
   if(isset($_GET["reset_password"])){
    if($_GET["reset_password"] == 'success'){
     echo '<h1 class="text-success" style="color: #FFFFFF; font-family: slkscr;">Clave modificada con éxito <br>Ya puedes iniciar sesión con tu nueva contraseña</h1>';
    }
   }
   ?>

   <div class="row">
    <div class="col-md-3">&nbsp;</div>
     <div class="col-md-6">
      <div class="panel panel-default">
       <div class="panel-heading">
        <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Iniciar sesi&oacuten</h3>
       </div>
       <div class="panel-body">
        <form method="POST" id="login_form">
         <div class="form-group" id="email_area">
          <label>Correo electr&oacutenico:</label>
          <input type="text" name="user_email" id="user_email" class="form-control" />
          <span id="user_email_error" class="text-danger"></span>
         </div>
         <div class="form-group" id="password_area" style="display:none;">
          <label>Contrase&ntildea</label>
          <input type="password" name="user_password" id="user_password" class="form-control" />
          <span id="user_password_error" class="text-danger"></span>
         </div>
         <div class="form-group" align="right">
          <input type="hidden" name="action" id="action" value="email" />
          <br><a href="registro.php">¿No tienes cuenta? Reg&iacutestrate ac&aacute</a> &nbsp &nbsp
          <input type="submit" name="next" id="next" class="btn btn-primary" value="siguiente" />
         </div>
        </form>
       </div>
      </div>
      <div align="center">
       <b><a href="forget_password.php?step1=1" style="color:#8D03D6;font-size: 16px;">Olvid&eacute mi contrase&ntildea</a></b><br>
       <b><a href="resend_email_otp.php" style="color:#8D03D6;font-size: 16px;">Reenviar c&oacutedigo de activaci&oacuten</a></b>
      </div>
     </div>
    </div>
   </div>
  <br/><br/>
 </body>
</html>

<script>

$(document).ready(function(){
 $('#login_form').on('submit', function(event){
  event.preventDefault();
  var action = $('#action').val();
  $.ajax({
   url:"login_verify.php",
   method:"POST",
   data:$(this).serialize(),
   dataType:"json",
   beforeSend:function()
   {
    $('#next').attr('disabled', 'disabled');
   },
   success:function(data)
   {
    $('#next').attr('disabled', false);
    if(action == 'email'){
     if(data.error != ''){
      $('#user_email_error').text(data.error);
     }else{
      $('#user_email_error').text('');
      $('#email_area').css('display', 'none');
      $('#password_area').css('display', 'block');
     }
    }
    else if(action == 'password'){
     if(data.error != ''){
      $('#user_password_error').text(data.error);
     }else{
      window.location.replace("home.php");
     }
    }
    $('#action').val(data.next_action);
   }
  })
 });
});

</script>



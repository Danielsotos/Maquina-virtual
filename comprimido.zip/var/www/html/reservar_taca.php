
<?php

//home.php
$connect = new PDO("mysql:host=127.0.0.1;dbname=lab", "daniel", "sql123");
session_start();

if(!isset($_SESSION["user_id"])){
 header("location:index.php");
}

sleep(1);

include('function.php');

$user_name = '';
$user_id = '';

if(isset($_SESSION["user_nombres"], $_SESSION["user_id"])){
 $user_nombres = $_SESSION["user_nombres"];
 $user_id = $_SESSION["user_id"];
   $data = array(
    ':user_id' => $user_id
   );
   $query = "
   SELECT * FROM labs
   WHERE id_lab = 1
   ";
   $statement = $connect->prepare($query);
   $statement->execute($data);
   $result = $statement->fetchAll();
   foreach($result as $row){
     if($row["ocupado"] == 1 && $row["ticket"] != $user_id){
       $query = "SELECT MAX(ticket) AS ticket from register_user";
       $statement = $connect->prepare($query);
       $statement->execute($data);
       $result = $statement->fetchAll();
       foreach($result as $row){
         $numero = $row['ticket'] + 1;
         $queuedata = array( ':numero' => $numero, ':user_id' => $user_id);
         $query = "UPDATE register_user SET ticket = :numero WHERE user_id = :user_id";
         $statement = $connect->prepare($query);
         $statement->execute($queuedata);
       }
        header("location:taca.php");
     }elseif($row["ocupado"] == 0){
      $query = "
      UPDATE labs SET ocupado = 1, ultimo_uso = CURRENT_TIMESTAMP, ticket = :user_id WHERE id_lab = 1";
      $statement = $connect->prepare($query);
      $statement->execute($data);
      $query = "UPDATE register_user SET lab=1 WHERE user_id = :user_id";
      $statement = $connect->prepare($query);
      $statement->execute($data);
     }
   }

if(isset($_POST['codigo']) && $_POST['action'] == 'Descargar'){
   header('Content-disposition: attachment; filename=codigo.ino');
   header('Content-type: application/txt');
   echo '// Creado en www.milaboratorioremoto.com'.PHP_EOL.PHP_EOL;
   echo $_POST['codigo'];
   exit;
}elseif($_POST['action'] == 'Compilar'){
   if(strlen($_POST['codigo']) > 4){
        $r = rand();
        $name='temp_'.date('m-d-Y_hia').$r;
        mkdir('temp_files/'.$name);
        mkdir('temp_files/'.$name.'/lib');
        mkdir('temp_files/'.$name.'/src');
        $handler = fopen('/var/www/html/temp_files/'.$name.'/src/sketch.ino', 'w+');
        $file1 = fwrite($handler, $_POST['codigo']);
        fclose($handler);
        $output = shell_exec('./compilar.sh '.$name);
        shell_exec('sudo rm -r temp_files/'.$name.'/');
   }else{
        $output = "Código vacío";
   }
}


}

?>
<!DOCTYPE html>
<html>
 <head>
  <title>Mi Laboratorio Remoto</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="http://code.jquery.com/jquery.js"></script>
  <script src="js/jquery-linedtextarea.js"></script>

     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
     <link href="css/jquery-linedtextarea.css" rel="stylesheet">
   <style type="text/css">
  @import url("slkscr/stylesheet.css");
  .silkscreen {
    font-family: slkscr;
  }
  .texto_blanco {
  }
.panel > .panel-heading {
    background-image: none;
    background-color: #8D03D6;
    color: #8D03D6;
}

.btn-default, .btn-default:hover, .btn-default:active, .btn-default:visited{
    background-color: #8D03D6 !important;
}
.btn-success, .btn-success:hover, .btn-success:active, .btn-success:visited{
    background-color: #8D03D6 !important;
}
.line-numbers {
    background-color: aqua
    text-align: right;
    position:relative;
    float:left;
    border: none;
    overflow: hidden;
}
.numbered {
    position: relative;
    float:left;
}

    input { 
        margin-top: 10px; 
    } 
      

</style>
 </head>
 <body style="background-color:#FF4800;">
  <br />
  <div class="container">
    <h3 align="center" style="color: #FFFFFF; font-family: slkscr;"><a href="https://www.milaboratorioremoto.com/login.php" style="color: #FFFFFF">Mi Laboratorio Remoto ( ' - ' )</a></h3>
   <br />
   <br />
   <div class="row">

    <div class="col-md-4">
     <div class="panel panel-default">
      <div class="panel-heading">
       <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Editor</h3>
      </div>
      <div class="panel-body">
       <div align="center">
         <form action="" method="post" id="formulario">
         <textarea name="codigo" rows="15" cols="45" class="lined">
<?php if(strlen($_POST['codigo']) > 4){
 echo $_POST['codigo'].trim();
}?>
</textarea>
        <br />
 <div align="center">
<input type="file" id="import" style="display: none;" accept=".ino" name="import"/>
<input type="button" value="Importar" onclick="document.getElementById('import').click();" class="btn btn-default" style="color: #FFFFFF"/>
        <input type="submit" value="Subir" name="action" class="btn btn-default" style="color: #FFFFFF"></input>
        <input type="submit" value="Descargar" name="action" class = "btn btn-default" style="color: #FFFFFF"></input>
       </div>
 </form><br>
        <h3>Entradas/Salidas :</h3>
<table>
  <tr>
    <th>Componente</th>
    <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
    <th>Pin</th>
    <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
    <th>Modo</th>
  </tr>
  <tr>
    <td>LED Rojo</td>
    <th></th>
    <td>11</td>
    <th></th>
    <td>Salida</td>
  </tr>
  <tr>
    <td>LED Verde</td>
    <th></th>
    <td>12</td>
    <th></th>
    <td>Salida</td>
  </tr>
  <tr>
    <td>LED Azul</td>
    <th></th>
    <td>13</td>
    <th></th>
    <td>Salida</td>
  </tr>
  <tr>
    <td>LDR</td>
    <th></th>
    <td>A5</td>
    <th></th>
    <td>Entrada</td>
  </tr>
  <tr>
    <td>Servo</td>
    <th></th>
    <td>2</td>
    <th></th>
    <td>Salida</td>
  </tr>
  <tr>
    <td>Rel&eacute</td>
    <th></th>
    <td>3</td>
    <th></th>
    <td>Salida</td>
  </tr>
</table>

       </div>
      </div>
     </div>
    </div>

    <div class="col-md-6">
     <div class="panel panel-default">
      <div class="panel-heading">
       <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Laboratorio</h3>
      </div>
      <div class="panel-body">
         <iframe width="500" height="300" src="https://arduinoremoto.ddns.net:8001/stream.mjpg"></iframe>

<p>Monitor Serial:</p>
<textarea readonly name="consola" rows="5" cols="75" style="background-color: black;color:#008000;">
<?php if($_POST['action'] == 'Compilar' && strlen($_POST['codigo']) > 4){
   echo substr($output,0,15);
   echo substr($output,173,29);
   if(substr($output,-24,-3) == 'Make failed with code'){
      echo substr($output,-24).'Error de compilación ( T - T )';
   }else{
      echo 'Compilado correctamente ( @ - @ )';
   }
}elseif($_POST['action'] == 'Compilar'){
  echo $output;
 }
?>
</textarea>
      </div>
    </div>
</div>
    <div class="col-md-2">
     <div class="panel panel-default">
      <div class="panel-heading">
       <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Usuario</h3>
      </div>
      <div class="panel-body">
       <div align="center">
        <?php
        Get_user_avatar($user_id, $connect);
        echo '<br /><br />';
        echo $user_nombres;
        ?>
        <br />
        <br />
        <a href="logout.php" class="btn btn-default" style="color: #FFFFFF">Cerrar sesi&oacuten</a>
        <br />
        <br />
        <button onclick="history.go(-1);" class="btn btn-default" style="color: #FFFFFF">Volver atr&aacutes </button>
	<br /><br />
        <p style="color: #8D03D6"> Al finalizar el tiempo volverá automáticamente a la vista anterior.</p>
       </div>
      </div>
     </div>
    </div>
  </div>
  <br />
  <br />

<script>


let input = document.querySelector('input')
let textarea = document.querySelector('textarea')

input.addEventListener('change', () => {
    let files = input.files;
    if (files.length == 0) return;
    var file = files[0];
    let reader = new FileReader();
    reader.onload = (e) => {
        var file = e.target.result;
        var lines = file.split(/\r\n|\n/);
        textarea.value = lines.join('\n');
    };
    reader.onerror = (e) => alert(e.target.error.name);
    reader.readAsText(file);
});

$(document).ready(function(){

   $(".lined").linedtextarea();

});

</script>

 </body>
</html>

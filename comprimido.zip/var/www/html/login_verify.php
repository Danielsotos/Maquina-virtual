<?php

include('database_connection.php');

session_start();

$error = '';

$next_action = '';

sleep(1);

if(isset($_POST["action"])){

 if($_POST["action"] == 'email'){
  if($_POST["user_email"] != ''){

   $user_email = $_POST["user_email"];

   $data = array(':user_email' => $user_email);
   $query = "SELECT * FROM register_user WHERE user_email = :user_email";
   $statement = $connect->prepare($query);
   $statement->execute($data);
   $total_row = $statement->rowCount();
   if($total_row == 0){
    $error = 'Email no encontrado en nuestros registros';
    $next_action = 'email';
   }else{
    $result = $statement->fetchAll();
    foreach($result as $row){
     $_SESSION["register_user_id"] = $row["user_id"];
     $_SESSION["user_nombres"] = $row["user_nombres"];
     $_SESSION['user_email'] = $row["user_email"];
     $_SESSION["user_password"] = $row["user_password"];
    }
    if($row["user_email_status"] == 'not verified'){
     $error = 'No se ha verificado la cuenta, por favor revise el código enviado al registrarse o abajo haga click en Reenviar código de activación.';
    }else{
    $next_action = 'password';
    }
   }
  }else{
   $error = 'Se requiere especificar un EMail';
   $next_action = 'email';
  }
 }

 if($_POST["action"] == 'password'){
  if($_POST["user_password"] != ''){
   if(password_verify($_POST["user_password"], $_SESSION["user_password"])){
    $data = array(':user_id'  => $_SESSION["register_user_id"], ':last_activity'=> date('d-m-y h:i:s'));
    $query = "INSERT INTO login_data (user_id, last_activity) VALUES (:user_id, :last_activity)";
    $statement = $connect->prepare($query);

    if($statement->execute($data)){
     $_SESSION['login_id'] = $connect->lastInsertId();
    }
    $_SESSION['user_id'] = $_SESSION['register_user_id'];
    unset($_SESSION["register_user_id"]);
    unset($_SESSION["user_email"]);
    unset($_SESSION["user_password"]);
    unset($_SESSION["login_otp"]);
   }else{
    $error = 'Contraseña incorrecta';
    $next_action = 'password';
   }
  }else{
   $error = 'Se requiere una contraseña';
   $next_action = 'password';
  }
 }

 $output = array('error'=>$error, 'next_action'=>$next_action);
 echo json_encode($output);
}

?>


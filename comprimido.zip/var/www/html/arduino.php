
<?php

session_start();

if(!isset($_SESSION["user_id"])){
 header("location:login.php");
}

include('database_connection.php');
include('function.php');

$user_name = '';
$user_id = '';

if(isset($_SESSION["user_nombres"], $_SESSION["user_id"])){
   $user_nombres = $_SESSION["user_nombres"];
   $user_id = $_SESSION["user_id"];
   $data = array(':user_id' => $user_id);
   $query = "SELECT * FROM register_user WHERE user_id = :user_id";
   $statement = $connect->prepare($query);
   $statement->execute($data);
   $result = $statement->fetchAll();
   foreach($result as $row){
      $espera = $row['ticket'];
      $asignado = $row['lab'];
   }
   $query = "SELECT * FROM labs WHERE id_lab = 1";
   $statement = $connect->prepare($query);
   $statement->execute($data);
   $result = $statement->fetchAll();
   foreach($result as $row){
      $inicio = $row['ultimo_uso'];
      $diff = 180-(strtotime(date('Y-m-d H:i:s')) - strtotime($inicio));
   }

if(isset($_POST['codigo']) && $_POST['action'] == 'Descargar'){
   header('Content-disposition: attachment; filename=codigo.ino');
   header('Content-type: application/txt');
   echo '// Creado en www.milaboratorioremoto.com'.PHP_EOL.PHP_EOL;
   echo $_POST['codigo'];
   exit;
}elseif($_POST['action'] == 'Compilar'){
   if(strlen($_POST['codigo']) > 4){
        $r = rand();
        $name='temp_'.date('m-d-Y_hia').$r;
        mkdir('temp_files/'.$name);
        mkdir('temp_files/'.$name.'/lib');
        mkdir('temp_files/'.$name.'/src');
        $handler = fopen('/var/www/html/temp_files/'.$name.'/src/sketch.ino', 'w+');
        $file1 = fwrite($handler, $_POST['codigo']);
        fclose($handler);
//        $output = shell_exec('./var/www/html/compilar.sh '.$name.'2>&1');
	$output = shell_exec('cd /var/www/html/temp_files/'.$name.' && ino build 2>&1');
        shell_exec('sudo rm -r temp_files/'.$name.'/');
   }else{
        $output = "Código vacío";
   }
}elseif($_POST['action'] == 'Cancelar reserva'){
         $queuedata = array( ':user_id' => $user_id);
         $query = "UPDATE register_user SET ticket = 0 WHERE user_id = :user_id";
         $statement = $connect->prepare($query);
         $statement->execute($queuedata);
         $queuedata = array( ':espera' => $espera);
         $query = "UPDATE register_user SET ticket = ticket - 1 WHERE ticket > :espera";
         $statement = $connect->prepare($query);
         $statement->execute($queuedata);
         $espera = 0;
}


}

?>
<!DOCTYPE html>
<html>
 <head>
  <title>Mi Laboratorio Remoto</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="http://code.jquery.com/jquery.js"></script>
  <script src="js/jquery-linedtextarea.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="css/jquery-linedtextarea.css" rel="stylesheet">
  <style type="text/css">
    @import url("slkscr/stylesheet.css");
    .silkscreen {
      font-family: slkscr;
    }
    .panel > .panel-heading {
      background-image: none;
      background-color: #8D03D6;
      color: #8D03D6;
    }
    .btn-default, .btn-default:hover, .btn-default:active, .btn-default:visited{
      background-color: #8D03D6 !important;
    }
    .btn-success, .btn-success:hover, .btn-success:active, .btn-success:visited{
      background-color: #8D03D6 !important;
    }
    .line-numbers {
      background-color: aqua
      text-align: right;
      position:relative;
      float:left;
      border: none;
      overflow: hidden;
    }
    .numbered {
      position: relative;
      float:left;
    }
    input {
      margin-top: 10px;
    }
  </style>
 </head>
 <body style="background-color:#FF4800;">
 <br />
 <div class="container">
   <h3 align="center" style="color: #FFFFFF; font-family: slkscr;"><a href="https://www.milaboratorioremoto.com/login.php" style="color: #FFFFFF">Mi Laboratorio Remoto ( ' - ' )</a></h3>
   <br /><br />
   <div class="row">
     <div class="col-md-4">
       <div class="panel panel-default">
         <div class="panel-heading">
           <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Laboratorio</h3>
         </div>
         <div class="panel-body">
           <div align="center">
             <iframe width="320" height="220" src="https://arduinoremoto.ddns.net:8001/stream.mjpg"></iframe>
             <br /><br />
             <?php if($espera == 0 and $asignado == 0){?>
               <a href= "https://arduinoremoto.ddns.net/taca.php?id=<?php echo $user_id; ?>" class="btn btn-default" style="color: #FFFFFF">Reservar</a>
             <?php }elseif($asignado == 1){ ?>
               <p style="color: #8D03D6">Aún lo tienes reservado por:</p>
               <span id="countdown_asig" class="timer_asig"></span>
             <?php }else{?>
               <form action="" method="post" id="formulario">
                 <input type="submit" value="Cancelar reserva" name="action" class="btn btn-default" style="color: #FFFFFF"></input>
               </form>
               <p style="color: #8D03D6"> Tienes el puesto N° <b><?php echo $espera ?></b> en la fila</p>
               <p style="color: #8D03D6"><b>Tiempo estimado de espera:</b></p>
               <span id="countdown" class="timer"></span>
             <?php }?>
             <h3>Entradas/Salidas :</h3>
             <table> <tr>
               <th>Componente</th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th><th>Pin</th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th><th>Modo</th>
               </tr><tr>
               <td>LED Rojo</td><th></th><td>11</td><th></th><td>Salida</td>
               </tr><tr>
               <td>LED Verde</td><th></th><td>12</td><th></th><td>Salida</td>
               </tr><tr>
               <td>LED Azul</td><th></th><td>13</td><th></th><td>Salida</td>
               </tr><tr>
               <td>LDR</td><th></th><td>A5</td><th></th><td>Entrada</td>
               </tr><tr>
               <td>Servo</td><th></th><td>2</td><th></th><td>Salida</td>
               </tr><tr>
               <td>Rel&eacute</td><th></th><td>3</td><th></th><td>Salida</td>
               </tr>
             </table>
           </div>
         </div>
       </div>
     </div>

     <div class="col-md-6">
       <div class="panel panel-default">
         <div class="panel-heading">
           <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Editor</h3>
         </div>
         <div class="panel-body">
           <h3 align="center"> Escribe o importa tu código:</h3><br>
           <form action="" method="post" id="formulario">
             <textarea name="codigo" rows="12" cols="75" class="lined">
             <?php if(strlen($_POST['codigo']) > 4){
               echo $_POST['codigo'].trim();
             }?>
             </textarea>
           <div align="center">
             <input type="file" id="import" style="display: none;" accept=".ino" name="import"/>
             <input type="button" value="Importar" onclick="document.getElementById('import').click();" class="btn btn-default" style="color: #FFFFFF"/>
             <input type="submit" value="Compilar" name="action" class="btn btn-default" style="color: #FFFFFF"></input>
             <input type="submit" value="Descargar" name="action" class = "btn btn-default" style="color: #FFFFFF"></input>
           </div>
           </form>
           <br><br>
           <p>Salida de compilador:</p>
           <textarea readonly name="consola" rows="5" cols="75" style="background-color: black;color:#008000;">
           <?php if($_POST['action'] == 'Compilar' && strlen($_POST['codigo']) > 4){
             echo substr($output,0,15);
             echo substr($output,173,29);
             if(substr($output,-24,-3) == 'Make failed with code'){
               echo substr($output,-24).'Error de compilación ( T - T )';
             }else{
               echo 'Compilado correctamente ( @ - @ )';
             }
           }elseif($_POST['action'] == 'Compilar'){
             echo $output;
           }?>
           </textarea>
         </div>
       </div>
     </div>
     <div class="col-md-2">
       <div class="panel panel-default">
         <div class="panel-heading">
           <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Usuario</h3>
         </div>
         <div class="panel-body">
           <div align="center">
             <?php
               Get_user_avatar($user_id, $connect);
               echo '<br /><br />';
               echo $user_nombres;
             ?>
             <br /><br />
             <a href="logout.php" class="btn btn-default" style="color: #FFFFFF">Cerrar sesi&oacuten</a>
             <br /><br />
             <a href="home.php" class="btn btn-default" style="color: #FFFFFF">Volver atr&aacutes </a>
           </div>
         </div>
       </div>
     </div>
   </div>
   <br /><br />

<script>
let input = document.querySelector('input')
let textarea = document.querySelector('textarea')

input.addEventListener('change', () => {
  let files = input.files;
  if (files.length == 0) return;
  var file = files[0];
  let reader = new FileReader();
  reader.onload = (e) => {
    var file = e.target.result;
    var lines = file.split(/\r\n|\n/);
    textarea.value = lines.join('\n');
  };
  reader.onerror = (e) => alert(e.target.error.name);
  reader.readAsText(file);
});

$(document).ready(function(){
  $(".lined").linedtextarea();
});
</script>

<script>
  var initialTime = <?php echo $diff + 180*($espera-1); ?>;
  var seconds = initialTime;
  function timer() {
    var days        = Math.floor(seconds/24/60/60);
    var hoursLeft   = Math.floor((seconds) - (days*86400));
    var hours       = Math.floor(hoursLeft/3600);
    var minutesLeft = Math.floor((hoursLeft) - (hours*3600));
    var minutes     = Math.floor(minutesLeft/60);
    var remainingSeconds = 59 + (seconds % 60);
    if (remainingSeconds < 10) {
        remainingSeconds = "0" + remainingSeconds; 
    }
    document.getElementById('countdown').innerHTML = "<p style=\"color: #8D03D6\">" + minutes + " min, " + remainingSeconds+ " segs </p><button class=\"btn btn-default\" style=\"color: #FFFFFF\" onClick=\"window.location.href=window.location.href\">Actualizar</button>";
    if (minutes == 0 && remainingSeconds == 0) {
      clearInterval(countdownTimer);
      document.getElementById('countdown').innerHTML = "<a href= \"https://arduinoremoto.ddns.net/taca.php?id=<?php echo $user_id; ?>\" class=\"btn btn-default\" style=\"color: #FFFFFF\">Entrar</a>";
    }else {
      seconds--;
    }
  }
  var countdownTimer = setInterval('timer()', 1000);
</script>

<script>
  var initialTime_asig = <?php echo $diff; ?>;
  var seconds_asig = initialTime_asig;
  function timer_asig() {
    var days_asig        = Math.floor(seconds_asig/24/60/60);
    var hoursLeft_asig   = Math.floor((seconds_asig) - (days_asig*86400));
    var hours_asig       = Math.floor(hoursLeft_asig/3600);
    var minutesLeft_asig = Math.floor((hoursLeft_asig) - (hours_asig*3600));
    var minutes_asig     = Math.floor(minutesLeft_asig/60);
    var remainingSeconds_asig = 59 + (seconds_asig % 60);
    if (remainingSeconds_asig < 10) {
        remainingSeconds_asig = "0" + remainingSeconds_asig; 
    }
    document.getElementById('countdown_asig').innerHTML = "<p style=\"color: #8D03D6\">" + minutes_asig + " min, " + remainingSeconds_asig + " segs" + "</p> <a href= \"https://arduinoremoto.ddns.net/taca.php?id=<?php echo $user_id; ?>\" class=\"btn btn-default\" style=\"color: #FFFFFF\">Entrar</a>";
    if (minutes_asig == 0 && remainingSeconds_asig == 0) {
      clearInterval(countdownTimer_asig);
      document.getElementById('countdown_asig').innerHTML = "<p style=\"color: #8D03D6\"><b>Tiempo agotado</b></p> <a href= \"https://arduinoremoto.ddns.net/taca.php?id=<?php echo $user_id; ?>\" class=\"btn btn-default\" style=\"color: #FFFFFF\">Reservar</a>";
    }else {
      seconds_asig--;
    }
  }
  var countdownTimer_asig = setInterval('timer_asig()', 1000);
</script>

</body>
</html>

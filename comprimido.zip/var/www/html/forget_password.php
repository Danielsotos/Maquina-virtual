<?php


include('database_connection.php');

$message = '';

session_start();

if(isset($_SESSION["user_id"])){
 header("location:home.php");
}

if(isset($_POST["submit"])){
 if(empty($_POST["user_email"])){
  $message = '<div class="alert alert-danger">Se necesita una direcci&oacuten de correo electr&oacutenico</div>';
 }else{
  $data = array(':user_email' => trim($_POST["user_email"]));
  $query = "SELECT * FROM register_user WHERE user_email = :user_email";
  $statement = $connect->prepare($query);
  $statement->execute($data);
  if($statement->rowCount() > 0){
   $result = $statement->fetchAll();
   foreach($result as $row){
    if($row["user_email_status"] == 'not verified'){
     $message = '<div class="alert alert-info">No se ha verificado la direcci&oacuten de correo electr&oacutenico, por favor verificar <a href="resend_email_otp.php">ac&aacute</a></div>';
    }else{
     $user_otp = rand(100000, 999999);
     $sub_query = "UPDATE register_user SET user_otp = '".$user_otp."' WHERE user_id = '".$row["user_id"]."'";
     $connect->query($sub_query);
     $ch = curl_init();
     curl_setopt($ch, CURLOPT_URL, 'https://api.mailgun.net/v3/mg.milaboratorioremoto.com/messages');
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_POST, 1);
     $post = array(
      'from' => 'Mi Laboratorio Remoto <no-responder@innovacionyrobotica.com>',
      'to' => $_POST["user_email"],
      'subject' => 'Cambio de contraseña',
      'html' => '<p>Para cambiar su contraseña haga click <a href="http://www.milaboratorioremoto.com/forget_password.php?step2=1&code='.$row["user_activation_code"].'">acá</a> e ingrese el siguiente código de verificación: <b>'.$user_otp.'</b></p>'
     );
     curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
     curl_setopt($ch, CURLOPT_USERPWD, 'api' . ':' . 'c8faabca20845bf3108145726e71713a-2fbe671d-4a91905c');
     $result = curl_exec($ch);
     if (curl_errno($ch)) {
      echo 'Error:' . curl_error($ch);
     }else{
      echo '<script>alert("Por favor revisar correo electrónico para obtener el código y confirmar la cuenta")</script>';
      echo '<script>window.location.replace("forget_password.php?step2=1&code=' . $row["user_activation_code"] . '")</script>';
     }
     curl_close($ch);
    }
   }
  }else{
   $message = '<div class="alert alert-danger">No se encontr&oacute esta direcci&oacuten en nuestros registros</div>';
  }
 }
}

if(isset($_POST["check_otp"])){
 if(empty($_POST["user_otp"])){
  $message = '<div class="alert alert-danger">C&oacutedigo de verificaci&oacuten:</div>';
 }else{
  $data = array(':user_activation_code'  => $_POST["user_code"],':user_otp'     => $_POST["user_otp"]);
  $query = "SELECT * FROM register_user WHERE user_activation_code = :user_activation_code AND user_otp = :user_otp";
  $statement = $connect->prepare($query);
  $statement->execute($data);
  if($statement->rowCount() > 0){
   echo '<script>window.location.replace("forget_password.php?step3=1&code=' . $_POST["user_code"] . '")</script>';
  }else{
   $message = '<div class="alert alert-danger">C&oacutedigo inv&aacutelido</div>';
  }
 }
}

if(isset($_POST["change_password"])){
 $new_password = $_POST["user_password"];
 $confirm_password = $_POST["confirm_password"];
 if($new_password == $confirm_password){
  $query = "UPDATE register_user SET user_password = '".password_hash($new_password, PASSWORD_DEFAULT)."' WHERE user_activation_code = '".$_POST["user_code"]."'";
  $connect->query($query);
  echo '<script>window.location.replace("login.php?reset_password=success")</script>';
 }else{
  $message = '<div class="alert alert-danger">Confirmaci&oacuten de nueva contrase&ntildea no coincide</div>';
 }
}

?>

<!DOCTYPE html>
<html>
 <head>
  <title>Mi Laboratorio Remoto</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <script src="http://code.jquery.com/jquery.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <style type="text/css">
  @import url("slkscr/stylesheet.css");
  .silkscreen {
    font-family: slkscr;
  }
  .panel > .panel-heading {
    background-image: none;
    background-color: #8D03D6;
    color: #8D03D6;
  }
  .btn-primary, .btn-primary:hover, .btn-primary:active, .btn-primary:visited{
    background-color: #8D03D6 !important;
  }
  .btn-success, .btn-success:hover, .btn-success:active, .btn-success:visited{
    background-color: #8D03D6 !important;
  }
  </style>
 </head>
 <body style="background-color:#FF4800;">
  <br />
  <div class="container">
   <h3 align="center" style="color: #FFFFFF; font-family: slkscr;"><a href="http://www.milaboratorioremoto.com/login.php" style="color: #FFFFFF">Mi Laboratorio Remoto ( ' - ' )</a></h3>
   <br />
   <div class="panel panel-default">
    <div class="panel-heading">
     <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Olvid&eacute mi contrase&ntildea</h3>
    </div>
    <div class="panel-body">
     <?php
     echo $message;
     if(isset($_GET["step1"])){
     ?>
     <form method="post">
      <div class="form-group">
       <label>Correo electr&oacutenico:</label>
       <input type="text" name="user_email" class="form-control" />
      </div>
      <div class="form-group">
       <input type="submit" name="submit" class="btn btn-success" value="Enviar código por EMail" /><br><br><a href="login.php">Volver al inicio de sesi&oacuten</a>
      </div>
     </form>
     <?php
     }
     if(isset($_GET["step2"], $_GET["code"])){
     ?>
     <form method="POST">
      <div class="form-group">
       <label>C&oacutedigo de verificaci&oacuten:</label>
       <input type="text" name="user_otp" class="form-control" />
      </div>
      <div class="form-group">
       <input type="hidden" name="user_code" value="<?php echo $_GET["code"]; ?>" />
       <input type="submit" name="check_otp" class="btn btn-success" value="Confirmar" />
      </div>
     </form>
     <?php
     }
     if(isset($_GET["step3"], $_GET["code"])){
     ?>
     <form method="post">
      <div class="form-group">
       <label>Nueva contrase&ntildea:</label>
       <input type="password" name="user_password" class="form-control" />
      </div>
      <div class="form-group">
       <label>Confirmar nueva contrase&ntildea:</label>
       <input type="password" name="confirm_password" class="form-control" />
      </div>
      <div class="form-group">
       <input type="hidden" name="user_code" value="<?php echo $_GET["code"]; ?>" />
       <input type="submit" name="change_password" class="btn btn-success" value="Cambiar" />
      </div>
     </form>
     <?php
     }
     ?>
    </div>
   </div>
  </div>
  <br /><br />
 </body>
</html>


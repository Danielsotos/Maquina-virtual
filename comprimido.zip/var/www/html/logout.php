<?php

//logout.php
include('database_connection.php');
session_start();
include('function.php');
$user_name = '';
$user_id = '';
if(isset($_SESSION["user_nombres"], $_SESSION["user_id"])){
   $user_nombres = $_SESSION["user_nombres"];
   $user_id = $_SESSION["user_id"];
   $data = array(':user_id' => $user_id);
   $query = "SELECT * FROM register_user WHERE register_user_id = :user_id";
   $statement = $connect->prepare($query);
   $statement->execute($data);
   $result = $statement->fetchAll();
   foreach($result as $row){
      $espera = $row['ticket'];
      $lab = $row['lab'];
   }
   $query = "SELECT * FROM labs WHERE id_lab=1";
   $statement = $connect->prepare($query);
   $statement->execute($data);
   $result = $statement->fetchAll();
   foreach($result as $row){
      $labticket = $row['ticket'];
   }
 if($espera > 0){
   $queuedata = array( ':user_id' => $user_id);
   $query = "UPDATE register_user SET ticket = 0 WHERE register_user_id = :user_id";
   $statement = $connect->prepare($query);
   $statement->execute($queuedata);
   $queuedata = array( ':espera' => $espera);
   $query = "UPDATE register_user SET ticket = ticket - 1 WHERE ticket > :espera";
   $statement = $connect->prepare($query);
   $statement->execute($queuedata);
 }elseif($lab > 0){
   $queuedata = array( ':user_id' => $user_id);
   $query = "UPDATE register_user SET lab = 0 WHERE register_user_id = :user_id";
   $statement = $connect->prepare($query);
   $statement->execute($queuedata);
   $query = "UPDATE labs SET ticket = 0, ocupado = 0 WHERE ticket = :user_id";
   $statement = $connect->prepare($query);
   $statement->execute($queuedata);
 }elseif($labticket == $user_id){
   $queuedata = array( ':user_id' => $user_id);
   $query = "UPDATE labs SET ticket = 0 WHERE ticket = :user_id";
   $statement = $connect->prepare($query);
   $statement->execute($queuedata);
 }
}

session_destroy();
header("location:index.php");

?>



<?php

session_start();
if(isset($_SESSION["user_id"])){
 header("location:home.php");
}

include('function.php');
include('database_connection.php');

$message = '';
$error_user_nombres = '';
$error_user_apellidos = '';
$error_user_email = '';
$error_user_password = '';
$user_nombres = '';
$user_apellidos = '';
$user_country = '';
$user_genero = '';
$user_dob = '';
$user_ocupacion = '';
$user_email = '';
$user_password = '';

if(isset($_POST["register"])){
  if(empty($_POST["user_nombres"])){
  $error_user_nombres = "<label class='text-danger'>Por favor ingresar el nombre</label>";
 }else{
  $user_nombres = trim($_POST["user_nombres"]);
  $user_nombres = htmlentities($user_nombres);
 }

 if(empty($_POST["user_apellidos"])){
  $error_user_apellidos = "<label class='text-danger'>Por favor ingresa tu apellido</label>";
 }else{
  $user_apellidos = trim($_POST["user_apellidos"]);
  $user_apellidos = htmlentities($user_apellidos);
 }

 if(empty($_POST["user_ocupacion"])){
  $error_user_ocupacion = "<label class='text-danger'>Por favor al menos ind&iacutecanos si eres estudiante de colegio, universitario, aficionado o profesional</label>";
 }else{
  $user_ocupacion = trim($_POST["user_ocupacion"]);
  $user_ocupacion = htmlentities($user_ocupacion);
 }

 if(empty($_POST["user_email"])){
  $error_user_email = '<label class="text-danger">Por favor ingresar una direcci&oacuten de correo electr&oacutenico</label>';
 }else{
  $user_email = trim($_POST["user_email"]);
  if(!filter_var($user_email, FILTER_VALIDATE_EMAIL)){
   $error_user_email = '<label class="text-danger">Ingrese una direcci&oacuten de EMail v&aacutelida</label>';
  }
 }

 if(empty($_POST["user_password"])){
  $error_user_password = '<label class="text-danger">Ingrese una contrase&ntildea</label>';
 }else{
  $user_password = trim($_POST["user_password"]);
  $user_password = password_hash($user_password, PASSWORD_DEFAULT);
 }

 if($error_user_nombres == '' && $error_user_apellidos == '' && $error_user_ocupacion == '' && $error_user_email == '' && $error_user_password == ''){
  $user_activation_code = md5(rand());

  $user_otp = rand(100000, 999999);

  $query = "SELECT * FROM `register_user` WHERE user_email = :user_email";
  $statement = $connect->prepare($query);

  $statement->execute(
   array(':user_email' => $user_email)
  );
  $no_of_row = $statement->rowCount();

  if($no_of_row > 0){
   $message = '<label class="text-danger">El correo electr&oacutenico ingresado ya est&aacute asociado con una cuenta</label>';
  }else{

  $connect->query('KILL CONNECTION_ID()');
  $connect = null;

  $conn = mysqli_connect("localhost", "daniel", "sql123", "lab");
  $user_country = trim($_POST["user_country"]);
  $user_genero = trim($_POST["user_genero"]);
  $user_dob = trim($_POST["user_dob"]);
  $user_email_status = 'not verified';
echo "hola";

  $user_avatar = make_avatar(strtoupper($user_nombres[0]));
echo "bye";
  $sql = "INSERT INTO `register_user` (user_nombres, user_apellidos, user_email, user_password, user_country, user_genero, user_dob, user_ocupacion, user_activation_code, user_email_status, user_otp, user_avatar) VALUES ('$user_nombres', '$user_apellidos', '$user_email', '$user_password', '$user_country', '$user_genero', '$user_dob', '$user_ocupacion', '$user_activation_code', '$user_email_status', '$user_otp', '$user_avatar')";

  $result = mysqli_query($conn, $sql);

  if($result){
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://api.mailgun.net/v3/mg.milaboratorioremoto.com/messages');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  $post = array(
      'from' => 'Mi Laboratorio Remoto <no-responder@innovacionyrobotica.com>',
      'to' => $user_email,
      'subject' => 'Activación de cuenta',
      'html' => '<p>Para activar su cuenta haga click <a href="http://www.milaboratorioremoto.com/email_verify.php?code='.$user_activation_code.'">acá</a> e ingrese el siguiente código de verificación: <b>'.$user_otp.'</b></p>'
  );
  curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_USERPWD, 'api' . ':' . 'c8faabca20845bf3108145726e71713a-2fbe671d-4a91905c');
  $result = curl_exec($ch);
  if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
  }else{
     echo '<script>alert("Revise su correo electrónico para activar la cuenta antes de iniciar sesión.")</script>';
     echo '<script>window.location.replace("email_verify.php?code='.$user_activation_code.'");</script>';
 }
  curl_close($ch);

  }else{
    $message = '<label class="text-danger">Ocurri&oacute un error, por favor intente nuevamente</label>';
  }

   mysqli_close($conn);

  }
}
}

?>*/
<!DOCTYPE html>
<html>
 <head>
  <title>Mi Laboratorio Remoto</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <script src="http://code.jquery.com/jquery.js"></script>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <style type="text/css">
  @import url("slkscr/stylesheet.css");
  .silkscreen {
    font-family: slkscr;
  }
  .btn-success, .btn-success:hover, .btn-success:active, .btn-success:visited {
    background-color: #8D03D6 !important;
  }
  .panel > .panel-heading {
    background-image: none;
    background-color: #8D03D6;
    color: #8D03D6;
  }
  </style>
 </head>
 <body style="background-color:#FF4800;">
  <br />
  <div class="container">
   <h3 align="center" style="color: #FFFFFF; font-family: slkscr;"><a href="http://www.practicasremotas.com/index.php" style="color: #FFFFFF">Mi Laboratorio Remoto ( * - * )</a></h3>
   <br />
   <div class="panel panel-default">
    <div class="panel-heading">
     <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Registro</h3>
    </div>
    <div class="panel-body">
     <?php echo $message; ?>
     <form method="post">
      <div class="form-group">
       <label>Correo electr&oacutenico:</label>
       <input type="text" name="user_email" class="form-control" />
       <?php echo $error_user_email; ?>
      </div>
      <div class="form-group">
       <label>Ingresa una contrase&ntildea:</label>
       <input type="password" name="user_password" class="form-control" />
       <?php echo $error_user_password; ?>
      </div>
      <div class="form-group">
       <label>Ingresa tu(s) nombre(s):</label>
       <input type="text" name="user_nombres" class="form-control" />
       <?php echo $error_user_nombres; ?>
      </div>
      <div class="form-group">
       <label>Ingresa tu(s) apellido(s):</label>
       <input type="text" name="user_apellidos" class="form-control" />
       <?php echo $error_user_apellidos; ?>
      </div>
      <div class="form-group">
      <label>G&eacutenero:</label>
        <select id = "user_genero" name="user_genero" class="form-control">
        <option value="F">Femenino</option>
        <option value="M">Masculino</option>
        <option value="D" selected>Prefiero no indicarlo</option>
        </select>
      </div>
      <div class="form-group">
      <label>Fecha de nacimiento:</label>
        <input type="date" id="user_dob" name="user_dob" class="form-control">
      </div>
      <div class="form-group">
       <label>Pa&iacutes:</label>
        <select id = "user_country" name="user_country" class="form-control">
    	<option value="AF">Afganist&aacuten</option>
    	<option value="AL">Albania</option>
    	<option value="DE">Alemania</option>
    	<option value="AD">Andorra</option>
    	<option value="AO">Angola</option>
    	<option value="AI">Anguilla</option>
    	<option value="AQ">Ant&aacutertida</option>
    	<option value="AG">Antigua y Barbuda</option>
    	<option value="AN">Antillas Holandesas</option>
    	<option value="SA">Arabia Saudita­</option>
    	<option value="DZ">Argelia</option>
    	<option value="AR">Argentina</option>
    	<option value="AM">Armenia</option>
    	<option value="AW">Aruba</option>
    	<option value="AU">Australia</option>
    	<option value="AT">Austria</option>
    	<option value="BS">Bahamas</option>
    	<option value="BH">Bahrein</option>
    	<option value="BD">Bangladesh</option>
    	<option value="BB">Barbados</option>
    	<option value="BE">B&eacutelgica</option>
    	<option value="BZ">Belice</option>
    	<option value="BJ">Benin</option>
    	<option value="BM">Bermudas</option>
    	<option value="BY">Bielorrusia</option>
    	<option value="MM">Birmania</option>
    	<option value="BO">Bolivia</option>
    	<option value="BA">Bosnia y Herzegovina</option>
    	<option value="BW">Botswana</option>
    	<option value="BR">Brasil</option>
    	<option value="BN">Brunei</option>
    	<option value="BG">Bulgaria</option>
    	<option value="BF">Burkina Faso</option>
    	<option value="BI">Burundi</option>
    	<option value="CV">Cabo Verde</option>
    	<option value="KH">Camboya</option>
    	<option value="CM">Camer&uacuten</option>
    	<option value="CA">Canad&aacute</option>
    	<option value="TD">Chad</option>
    	<option value="CL" selected>Chile</option>
    	<option value="CN">China</option>
    	<option value="CY">Chipre</option>
    	<option value="VA">Ciudad del Vaticano (Santa Sede)</option>
    	<option value="CO">Colombia</option>
    	<option value="KM">Comores</option>
    	<option value="CG">Congo</option>
    	<option value="CD">Congo, Rep&uacuteblica Democr&aacutetica del</option>
    	<option value="KR">Corea</option>
    	<option value="KP">Corea del Norte</option>
    	<option value="CI">Costa de Marf&iacute­l</option>
    	<option value="CR">Costa Rica</option>
    	<option value="HR">Croacia (Hrvatska)</option>
    	<option value="CU">Cuba</option>
    	<option value="DK">Dinamarca</option>
    	<option value="DJ">Djibouti</option>
    	<option value="DM">Dominica</option>
    	<option value="EC">Ecuador</option>
    	<option value="EG">Egipto</option>
    	<option value="SV">El Salvador</option>
    	<option value="AE">Emiratos &aacuterabes Unidos</option>
    	<option value="ER">Eritrea</option>
    	<option value="SI">Eslovenia</option>
    	<option value="ES">Espa&ntildea</option>
    	<option value="US">Estados Unidos</option>
    	<option value="EE">Estonia</option>
    	<option value="ET">Etiop&iacute­a</option>
    	<option value="FJ">Fiji</option>
    	<option value="PH">Filipinas</option>
    	<option value="FI">Finlandia</option>
    	<option value="FR">Francia</option>
    	<option value="GM">Gambia</option>
    	<option value="GE">Georgia</option>
    	<option value="GH">Ghana</option>
    	<option value="GI">Gibraltar</option>
    	<option value="GD">Granada</option>
    	<option value="GR">Grecia</option>
    	<option value="GL">Groenlandia</option>
    	<option value="GP">Guadalupe</option>
    	<option value="GU">Guam</option>
    	<option value="GT">Guatemala</option>
    	<option value="GY">Guayana</option>
    	<option value="GF">Guayana Francesa</option>
    	<option value="GN">Guinea</option>
    	<option value="GQ">Guinea Ecuatorial</option>
    	<option value="GW">Guinea-Bissau</option>
    	<option value="HT">Hait&iacute­</option>
    	<option value="HN">Honduras</option>
    	<option value="HU">Hungr&iacute­a</option>
    	<option value="IN">India</option>
    	<option value="ID">Indonesia</option>
    	<option value="IQ">Irak</option>
    	<option value="IR">Ir&aacuten</option>
    	<option value="IE">Irlanda</option>
    	<option value="BV">Isla Bouvet</option>
    	<option value="CX">Isla de Christmas</option>
    	<option value="IS">Islandia</option>
    	<option value="KY">Islas Caim&aacuten</option>
    	<option value="CK">Islas Cook</option>
    	<option value="CC">Islas de Cocos o Keeling</option>
    	<option value="FO">Islas Faroe</option>
    	<option value="HM">Islas Heard y McDonald</option>
    	<option value="FK">Islas Malvinas</option>
    	<option value="MP">Islas Marianas del Norte</option>
    	<option value="MH">Islas Marshall</option>
    	<option value="UM">Islas menores de Estados Unidos</option>
    	<option value="PW">Islas Palau</option>
    	<option value="SJ">Islas Svalbard y Jan Mayen</option>
    	<option value="TK">Islas Tokelau</option>
    	<option value="TC">Islas Turks y Caicos</option>
    	<option value="VI">Islas V&iacute­rgenes (EE.UU.)</option>
    	<option value="VG">Islas V&iacute­rgenes (Reino Unido)</option>
    	<option value="WF">Islas Wallis y Futuna</option>
    	<option value="IL">Israel</option>
    	<option value="IT">Italia</option>
    	<option value="JM">Jamaica</option>
    	<option value="JP">Jap&oacuten</option>
    	<option value="JO">Jordania</option>
    	<option value="KZ">Kazajist&aacuten</option>
    	<option value="KE">Kenia</option>
    	<option value="KG">Kirguizist&aacuten</option>
    	<option value="KI">Kiribati</option>
    	<option value="KW">Kuwait</option>
    	<option value="LA">Laos</option>
    	<option value="LS">Lesotho</option>
    	<option value="LV">Letonia</option>
    	<option value="LB">L&iacute­bano</option>
    	<option value="LR">Liberia</option>
    	<option value="LY">Libia</option>
    	<option value="LI">Liechtenstein</option>
    	<option value="LT">Lituania</option>
    	<option value="LU">Luxemburgo</option>
    	<option value="MK">Macedonia, Ex-Rep&uacuteblica Yugoslava de</option>
    	<option value="MG">Madagascar</option>
    	<option value="MY">Malasia</option>
    	<option value="MW">Malawi</option>
    	<option value="MV">Maldivas</option>
    	<option value="MT">Malta</option>
    	<option value="MA">Marruecos</option>
    	<option value="MQ">Martinica</option>
    	<option value="MU">Mauricio</option>
    	<option value="MR">Mauritania</option>
    	<option value="YT">Mayotte</option>
    	<option value="MX">M&eacutexico</option>
    	<option value="FM">Micronesia</option>
    	<option value="MD">Moldavia</option>
    	<option value="MC">M&oacutenaco</option>
    	<option value="MN">Mongolia</option>
    	<option value="MS">Montserrat</option>
    	<option value="MZ">Mozambique</option>
    	<option value="NA">Namibia</option>
    	<option value="NR">Nauru</option>
    	<option value="NP">Nepal</option>
    	<option value="NI">Nicaragua</option>
    	<option value="NG">Nigeria</option>
    	<option value="NU">Niue</option>
    	<option value="NF">Norfolk</option>
    	<option value="NO">Noruega</option>
    	<option value="NC">Nueva Caledonia</option>
    	<option value="NZ">Nueva Zelanda</option>
    	<option value="NL">Pa&iacute­ses Bajos</option>
    	<option value="PA">Panam&aacute</option>
    	<option value="PK">Paquist&aacuten</option>
    	<option value="PY">Paraguay</option>
    	<option value="PE">Per&uacute</option>
    	<option value="PN">Pitcairn</option>
    	<option value="PF">Polinesia Francesa</option>
    	<option value="PL">Polonia</option>
    	<option value="PT">Portugal</option>
    	<option value="PR">Puerto Rico</option>
    	<option value="QA">Qatar</option>
    	<option value="UK">Reino Unido</option>
    	<option value="CF">Rep&uacuteblica Centroafricana</option>
    	<option value="CZ">Rep&uacuteblica Checa</option>
    	<option value="ZA">Rep&uacuteblica de Sud&aacutefrica</option>
    	<option value="DO">Rep&uacuteblica Dominicana</option>
    	<option value="SK">Rep&uacuteblica Eslovaca</option>
    	<option value="RW">Ruanda</option>
    	<option value="RO">Rumania</option>
    	<option value="RU">Rusia</option>
    	<option value="EH">Sahara Occidental</option>
    	<option value="KN">Saint Kitts y Nevis</option>
    	<option value="WS">Samoa</option>
    	<option value="AS">Samoa Americana</option>
    	<option value="SM">San Marino</option>
    	<option value="VC">San Vicente y Granadinas</option>
    	<option value="SH">Santa Helena</option>
    	<option value="SN">Senegal</option>
    	<option value="SC">Seychelles</option>
    	<option value="SL">Sierra Leona</option>
    	<option value="SG">Singapur</option>
    	<option value="SY">Siria</option>
    	<option value="SO">Somalia</option>
    	<option value="LK">Sri Lanka</option>
    	<option value="SZ">Suazilandia</option>
    	<option value="SD">Sud&aacuten</option>
    	<option value="SE">Suecia</option>
    	<option value="CH">Suiza</option>
    	<option value="SR">Surinam</option>
    	<option value="TH">Tailandia</option>
    	<option value="TW">Taiw&aacuten</option>
    	<option value="TZ">Tanzania</option>
    	<option value="TJ">Tayikist&aacuten</option>
    	<option value="TF">Territorios Franceses del Sur</option>
    	<option value="TP">Timor Oriental</option>
    	<option value="TG">Togo</option>
    	<option value="TO">Tonga</option>
    	<option value="TT">Trinidad y Tobago</option>
    	<option value="TN">T&uacutenez</option>
    	<option value="TM">Turkmenist&aacuten</option>
    	<option value="TR">Turqu&iacute­a</option>
    	<option value="TV">Tuvalu</option>
    	<option value="UA">Ucrania</option>
    	<option value="UG">Uganda</option>
    	<option value="UY">Uruguay</option>
    	<option value="UZ">Uzbekist&aacuten</option>
    	<option value="VU">Vanuatu</option>
    	<option value="VE">Venezuela</option>
    	<option value="VN">Vietnam</option>
    	<option value="YE">Yemen</option>
    	<option value="YU">Yugoslavia</option>
    	<option value="ZM">Zambia</option>
    	<option value="ZW">Zimbawe</option>
    </select>
      </div>
      <div class="form-group">
       <label>Ocupaci&oacuten:</label>
       <input type="text" name="user_ocupacion" class="form-control" />
       <?php echo $error_user_ocupacion; ?>
      </div>
      <div class="form-group">
       <input type="submit" name="register" class="btn btn-success" value="Registrarme" />&nbsp;&nbsp;&nbsp;
       <br><br>
       <a href="index.php">¿Ya tienes cuenta? Inicia sesi&oacuten aqu&iacute</a>
      </div>
     </form>
    </div>
   </div>
  </div>
  <br />
  <br />
 </body>
</html>




<?php

//home.php

session_start();

if(!isset($_SESSION["user_id"])){
 header("location:index.php");
}

include('database_connection.php');
include('function.php');

$user_name = '';
$user_id = '';

if(isset($_SESSION["user_nombres"], $_SESSION["user_id"])){
 $user_nombres = $_SESSION["user_nombres"];
 $user_id = $_SESSION["user_id"];
}

?>

<!DOCTYPE html>
<html>
 <head>
  <title>Mi Laboratorio Remoto</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <script src="http://code.jquery.com/jquery.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <style type="text/css">
  @import url("slkscr/stylesheet.css");
  .silkscreen {
    font-family: slkscr;
  }
  .panel > .panel-heading {
    background-image: none;
    background-color: #8D03D6;
    color: #8D03D6;
  }
  .btn-default, .btn-default:hover, .btn-default:active, .btn-default:visited{
    background-color: #8D03D6 !important;
  }
  .btn-success, .btn-success:hover, .btn-success:active, .btn-success:visited{
    background-color: #8D03D6 !important;
  }
  .wrapper {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 10px;
    grid-auto-rows: minmax(100px, auto);
  }
  .taca {
    grid-column: 1;
    grid-row: 1;
  }
  .tacastatus {
    grid-column: 1;
    grid-row: 2;
  }
  ecostatus {
    grid-column: 2;
    grid-row: 2;
  }
  linestatus {
    grid-column: 3;
    grid-row: 2;
  }
  </style>
 </head>
 <body style="background-color:#FF4800;">
  <br />
  <div class="container">
   <h3 align="center" style="color: #FFFFFF; font-family: slkscr;"><a href="https://www.practicasremotas.com/index.php" style="color: #FFFFFF">Mi Laboratorio Remoto ( ' - ' )</a></h3>
   <br /><br />
   <div class="row">

    <div class="col-md-9">
     <div class="panel panel-default">
      <div class="panel-heading">
       <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Mi Laboratorio Remoto ( * - * )</h3>
      </div>
      <div class="panel-body">
       <h1 align="center">¡ Bienvenido <?php echo $user_nombres; ?> !</h1>
       <h3 align="center"> Escoge alguno de los laboratorios disponibles a continuación:</h3>
      </div>
      <div class="wrapper">
       <div class="taca"><a href="arduino.php"><img src="avatar/taca.png" width="150" height="150"></a></div>
       <div class="tacastatus"><img src="avatar/luz_verde.jpg" width="20" height="20">Habilitado</div>
       <div class="ecorobot"><a href="#"><img src="avatar/ecorobot.png" width="150" height="150"></a></div>
       <div class="linefollower"><a href="#"><img src="avatar/linefollower.png" width="150" height="150"></a></div>
       <div class="ecostatus"><img src="avatar/luz_roja.jpg" width="20" height="20">Pronto</div>
       <div class="linestatus"><img src="avatar/luz_roja.jpg" width="20" height="20">Pronto</div>
      </div>
     </div>
    </div>

    <div class="col-md-3">
     <div class="panel panel-default">
      <div class="panel-heading">
       <h3 class="panel-title" style="color: #FFFFFF; font-family: slkscr;">Usuario</h3>
      </div>
      <div class="panel-body">
       <div align="center">
        <?php
        Get_user_avatar($user_id, $connect);
        echo '<br /><br />';
        echo $user_nombres;
        ?>
        <br /><br />
        <a href="logout.php" class="btn btn-default" style="color: #FFFFFF">Cerrar sesi&oacuten</a>
       </div>
      </div>
     </div>
    </div>
   </div>
   <br/><br/>
  </div>
 </body>
</html>
